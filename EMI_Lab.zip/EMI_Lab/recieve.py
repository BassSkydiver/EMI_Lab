
#Created by Nathaniel McBride
#5/17/2023

from __future__ import print_function
import RPi.GPIO as GPIO
import os
import time
import sys

#Configuration
CLOCK_PIN = 27
DATA_PIN = 17

data_rate = 32
sleep_time = 1/(data_rate * 2)
start_time = 0

# Initialize GPIO
GPIO.setmode(GPIO.BCM)
GPIO.setup(CLOCK_PIN, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
GPIO.setup(DATA_PIN, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)

# Helper function to receive a single bit
def receive_bit():
    GPIO.wait_for_edge(CLOCK_PIN, GPIO.RISING)
    time.sleep(sleep_time)
    bit = GPIO.input(DATA_PIN)
    print(bit)
    return str(bit)

def delete_file_contents(file_path):
    try:
        with open(file_path, 'w') as file:
            file.write('')

        print(f"Successfully deleted the contents of the file '{file_path}'.")
    except IOError:
        print(f"Error: Unable to write to the file '{file_path}'.")

#Fucntion to reveive binary data
def receive_binary():
    binary_data = "0"
    start_time = time.time()
    while True:
        bit = receive_bit()
        if (time.time() - start_time) > 2:
            break
        else:
            start_time = time.time()
        binary_data += bit

    return binary_data

def insert_string_into_file(file_path, string_to_insert, position):
    try:
        with open(file_path, 'r') as file:
            contents = file.read()

        modified_contents = contents[:position] + string_to_insert + contents[position:]

        with open(file_path, 'w') as file:

            file.write(modified_contents)

        print(f"Successfully inserted the string into the file '{file_path}'.")
    except IOError:
        print(f"Error: Unable to read/write the file '{file_path}'.")

def convert_binary_to_text(filepath):
    # Open the binary data file in read mode
    with open(filepath, 'r') as file:
        # Read the binary data from the file
        binary_data = file.read()

        # Define the chunk size
        chunk_size = 8  # Assuming each character represents a single byte (8 bits)

        # Convert binary data to text
        text = ''
        for i in range(0, len(binary_data), chunk_size):
            # Extract a chunk of binary data
            chunk = binary_data[i:i + chunk_size]

            # Convert the binary chunk to an integer
            decimal_value = int(chunk, 2)

            # Convert the decimal value to a character
            character = chr(decimal_value)

            # Append the character to the text
            text += character

    return text

try:
    try:
        delete_file_contents('signal.txt')
        delete_file_contents('data.txt')
        print("Successfully cleared signal.txt and data.txt.")

    except:
        sys.exit("Error: could not clear signal.txt or data.txt.")

    print("Waiting for signal")

    while not GPIO.input(CLOCK_PIN):
        time.sleep(0.01)

    print("Signal detected")
    insert_string_into_file('signal.txt', receive_binary(), 0)
    print("Successfully recieved data.")

    insert_string_into_file('data.txt', convert_binary_to_text('signal.txt'), 0)

except:
    print("Error: data not recieved.")

finally:
    GPIO.cleanup()

