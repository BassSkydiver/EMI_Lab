#Created by Nathaniel McBride
#5/17/2023

from __future__ import print_function
import RPi.GPIO as GPIO
import os
import time
import sys

# Configuration
CLOCK_PIN = 17   # GPIO pin for clock
DATA_PIN = 18    # GPIO pin for data

START_PIN = 26

#Vars
data_rate = 32

#Initialize GPIO
GPIO.setmode(GPIO.BCM)
GPIO.setup(CLOCK_PIN, GPIO.OUT)
GPIO.setup(DATA_PIN, GPIO.OUT)
GPIO.setup(START_PIN, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)

GPIO.output(CLOCK_PIN, 0)
GPIO.output(DATA_PIN, 0)

#creates a binary string from a txt file
def text_to_binary(file_path):
    try:
        with open(file_path, 'r') as file:
            text = file.read()
            binary = '\n'.join(format(ord(char), '08b') for char in text)
            return binary
    except IOError:
        sys.exit(f"Error: Unable to read the file '{file_path}'.")

#Takes a string and puts it in a txt file
def insert_string_into_file(file_path, string_to_insert, position):
    try:
        with open(file_path, 'r') as file:
            contents = file.read()

        modified_contents = contents[:position] + string_to_insert + contents[position:]

        with open(file_path, 'w') as file:
            file.write(modified_contents)

        print(f"Successfully inserted the string into the file '{file_path}'.")
    except IOError:
        sys.exit(f"Error: Unable to read/write the file '{file_path}'.")

#delets the contents of a txt file
def delete_file_contents(file_path):
    try:
        with open(file_path, 'w') as file:
            file.write('')

        print(f"Successfully deleted the contents of the file '{file_path}'.")
    except IOError:
        sys.exit(f"Error: Unable to write to the file '{file_path}'.")

# Helper function to send a single bit
def send_bit(bit):
    GPIO.output(DATA_PIN, bit)
    GPIO.output(CLOCK_PIN, GPIO.HIGH)
    time.sleep(1/(data_rate*2))
    GPIO.output(CLOCK_PIN, GPIO.LOW)
    time.sleep(1/(2*data_rate))

def send_binary_file(file_place):
    with open(file_place, 'r') as file:
        data = file.read().replace("\n", "")

    for bit in data:
        send_bit(int(bit))
        print(bit)

    print(len(data))

file_path = 'bigfile.txt'

if not os.path.isfile(file_path):
    sys.exit(f"Error: Unable to detect file '{file_path}'.")

#deletes the contents of signal.txt
delete_file_contents('signal.txt')

#dumps data into signal.txt
insert_string_into_file('signal.txt', text_to_binary(file_path), 0)

try:
    GPIO.output(CLOCK_PIN, GPIO.HIGH)
    time.sleep(0.01)
    GPIO.output(CLOCK_PIN, GPIO.LOW)
    GPIO.output(DATA_PIN, GPIO.LOW)

    send_binary_file('signal.txt')
    print(f"Successfully transmitted '{file_path}'.")

    time.sleep(3)
    GPIO.output(CLOCK_PIN, GPIO.HIGH)
    time.sleep(0.2)
    GPIO.output(CLOCK_PIN, GPIO.LOW)
    print(f"End of transmit")

except:
    print("Transmit failed for '{file_path}'.")

finally:
    GPIO.cleanup()
